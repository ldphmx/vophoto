#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys
from .runner import main

if __name__ == '__main__':
    sys.exit(main())
